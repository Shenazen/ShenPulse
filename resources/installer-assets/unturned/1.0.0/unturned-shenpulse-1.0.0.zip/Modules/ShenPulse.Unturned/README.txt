ShenPulse Unturned 1.0.0
Module original ShenPulse. Partie solo, lancement sans BattlEye via Unturned.exe.
Connexion sortante TCP 127.0.0.1:58435. Aucun compte ou logiciel tiers requis.
Les bibliotheques du jeu ne sont pas redistribuees.
